import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule} from '@ionic/angular'
import { FormsModule } from '@angular/forms'
import { RouterModule } from '@angular/router'
import { DailyNewsComponent } from './daily-news/daily-news.component'
import {AddDailyNewsComponent } from './add-daily-news/add-daily-news.component'
import { EditDailyNewsComponent } from './edit-daily-news/edit-daily-news.component'
import { DataTablesModule } from 'angular-datatables';

@NgModule({
  declarations: [DailyNewsComponent,AddDailyNewsComponent,EditDailyNewsComponent],
  imports: [
    CommonModule,
    IonicModule,
    FormsModule,
    DataTablesModule,
    RouterModule.forChild([{path:'', component: DailyNewsComponent}, {path:'add-daily-news', component:  AddDailyNewsComponent}, {path: 'edit-daily-news', component:EditDailyNewsComponent }])
  ]
})
export class DailyNewsModuleModule { }
