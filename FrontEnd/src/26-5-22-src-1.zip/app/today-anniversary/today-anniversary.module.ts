import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { TodayAnniversaryPageRoutingModule } from './today-anniversary-routing.module';

import { TodayAnniversaryPage } from './today-anniversary.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    TodayAnniversaryPageRoutingModule
  ],
  declarations: [TodayAnniversaryPage]
})
export class TodayAnniversaryPageModule {}
