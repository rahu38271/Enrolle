import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular'
import { KaryakartaComponent} from './karyakarta/karyakarta.component'
import { RouterModule } from '@angular/router'
import { FormsModule } from '@angular/forms'
import { AddKaryakartaComponent } from './add-karyakarta/add-karyakarta.component'
import { EditKaryakartaComponent } from './edit-karyakarta/edit-karyakarta.component'
import {ImportKaryakartaComponent } from './import-karyakarta/import-karyakarta.component'
import { DataTablesModule } from 'angular-datatables';
import { NgxDropzoneModule } from 'ngx-dropzone';

@NgModule({
  declarations: [KaryakartaComponent,AddKaryakartaComponent,EditKaryakartaComponent,ImportKaryakartaComponent],
  imports: [
    CommonModule,
    IonicModule,
    FormsModule,
    NgxDropzoneModule,
    DataTablesModule,
    RouterModule.forChild([{path:'', component:KaryakartaComponent}, {path:'add-karyakarta', component:AddKaryakartaComponent},{path:'edit-karyakarta', component:EditKaryakartaComponent},{path:'import-karyakarta', component:ImportKaryakartaComponent}])
  ]
})
export class KaryakartaModuleModule { }
