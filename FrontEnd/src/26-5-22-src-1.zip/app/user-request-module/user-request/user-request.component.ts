import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { AlertController,LoadingController } from '@ionic/angular';



@Component({
  selector: 'app-user-request',
  templateUrl: './user-request.component.html',
  styleUrls: ['./user-request.component.scss'],
})
export class UserRequestComponent implements OnInit {

  myForm1: any;
  Mode = '';
  Status = '';
  tableName = '';

  mode: any = {
    header: 'माध्यम'
  };

  modeName: any = {
    header: ' माध्यमाचे नाव'
  };

  StatusHeader:any = {
    header: 'select Status'
  }


  constructor(public alertController: AlertController,public loadingController: LoadingController) { }

  resetForm(){
    this.myForm1.reset();
  }

  ngOnInit() { 
    $('#table11').DataTable({
      lengthMenu: [ [25, 50, 100, -1], [25, 50, 100, "All"] ],
      pageLength: 25,
      autoWidth: false,
      "columnDefs": [
        { "width": "40px", "targets": 0 },
        { "width": "70px", "targets": 1 },
        { "width": "150px", "targets": 2 },
        { "width": "200px", "targets": 3 },
        { "width": "60px", "targets": 4 },
        { "width": "60px", "targets": 5 },
      ],
    });
  }

  async presentLoading() {
    const loading = await this.loadingController.create({
      cssClass: 'my-custom-class',
      message: 'Searching...',
      duration: 2000
    });
    await loading.present();

    const { role, data } = await loading.onDidDismiss();
    console.log('Loading dismissed!');
  }

}
