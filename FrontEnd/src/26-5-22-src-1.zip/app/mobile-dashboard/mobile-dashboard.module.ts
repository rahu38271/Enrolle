import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MobileDashboardPageRoutingModule } from './mobile-dashboard-routing.module';

import { MobileDashboardPage } from './mobile-dashboard.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MobileDashboardPageRoutingModule
  ],
  declarations: [MobileDashboardPage]
})
export class MobileDashboardPageModule {}
