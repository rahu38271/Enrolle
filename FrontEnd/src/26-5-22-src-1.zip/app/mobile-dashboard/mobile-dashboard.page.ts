import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mobile-dashboard',
  templateUrl: './mobile-dashboard.page.html',
  styleUrls: ['./mobile-dashboard.page.scss'],
})
export class MobileDashboardPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
