import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-village',
  templateUrl: './add-village.component.html',
  styleUrls: ['./add-village.component.scss'],
})
export class AddVillageComponent implements OnInit {

  StateHeader:any = {
    header: 'Select State'
  }
  DistrictHeader: any = {
    header: 'Select District'
  }
  TalukaHeader:any = {
    header: 'Select Taluka'
  }

 

  myForm;
  State = '';
  District = '';
  Taluka = '';
  Village = '';

  constructor() { }

  ngOnInit() {}

  resetForm(){
    this.myForm.reset();
  }

}
