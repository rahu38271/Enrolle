import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SurveyListComponent } from './survey-list/survey-list.component'
import { AddSurveyComponent } from './add-survey/add-survey.component'
import { AddVillageComponent } from './add-village/add-village.component'

@NgModule({
  declarations: [SurveyListComponent,AddSurveyComponent,AddVillageComponent],
  imports: [
    CommonModule,
    IonicModule,
    FormsModule,
    RouterModule.forChild([{path:'', component:SurveyListComponent},{path:'add-survey', component:AddSurveyComponent},{path:'add-village', component:AddVillageComponent}])
  ]
})
export class SurveyModuleModule { }
