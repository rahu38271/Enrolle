import { Component, OnInit } from '@angular/core';
import { LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-add-survey',
  templateUrl: './add-survey.component.html',
  styleUrls: ['./add-survey.component.scss'],
})
export class AddSurveyComponent implements OnInit {

  mode:any = {
    header: 'माध्यम '
  }

  modeType:any = {
    header: 'माध्यमाचे नाव'
  }

  GenderHeader: any = {
    header: 'Select Gender'
  }

  FamilyHeadHeader: any = { 
    header: 'Sender Family Head'
  }

  SuspiciousHeader: any = {
    header: 'Is Suspicious'
  }

  StationHeader: any = {
    header: 'Is Out Station'
  }

  AliveDeadHeader: any = {
    header: 'Alive/Dead'
  }

  OccupationHeader : any = {
    header: 'Select Occupation'
  }

  KaryakartaHeader: any = {
    header:'Select Karyakarta'
  }

  InclinationHeader: any = {
    header:'Select Voting Inclination'
  }

  CasteHeader: any = {
    header: 'Select Caste'
  }

  BoothHeader: any = {
    header: 'Select Booth',
    cssClass: 'select-width'
  }

  PartyHeader: any = {
    header: 'Select Party'
  }

  GroupDHeader:any = {
    header: 'Select MobileData Group'
  }

  TemplateHeader:any = {
    header: 'Select SMS Template'
  }

  myForm;
  Name = '';
  Age = '';
  Gender = '';
  Booth = '';
  House = '';
  Mobile = '';
  Address = '';
  FamilyHead = '';
  Suspicious = '';
  Station = '';
  AliveDead = '';
  Occupation = '';
  Karyakarta = '';
  Inclination = '';
  Caste = '';
  Party = '';
  Date = '';
  Family = '';
  Disability = '';
  Education = '';
  AltMobile = '';
  Info = '';
  WorkLeft = '';
  Service = '';
 

  keyPressNumbers(event) {
    var charCode = (event.which) ? event.which : event.keyCode;
    // Only Numbers 0-9
    if ((charCode < 48 || charCode > 57)) {
      event.preventDefault();
      return false;
    } else {
      return true;
    }
  }

  onKeyPress(event) {
    if ((event.keyCode >= 65 && event.keyCode <= 90) || (event.keyCode >= 97 && event.keyCode <= 122) || event.keyCode == 32 || event.keyCode == 46) {
        return true
    }
    else {
        return false
    }
}

  constructor(public loadingController: LoadingController) { }

  ngOnInit() {}

  resetForm(){
    this.myForm.reset();
  }

  async presentLoading() {
    const loading = await this.loadingController.create({
      cssClass: 'my-custom-class',
      message: 'Saving Details...',
      duration: 2000
    });
    await loading.present();

    const { role, data } = await loading.onDidDismiss();
    console.log('Loading dismissed!');
  }

}
