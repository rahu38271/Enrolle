import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-document-repository',
  templateUrl: './add-document-repository.component.html',
  styleUrls: ['./add-document-repository.component.scss'],
})
export class AddDocumentRepositoryComponent implements OnInit {

  type:any = {
    header: 'प्रकार'
  }
  department: any = {
    header: ' संबंधित विभाग '
  }
  
  myForm;
  Type = '';
  Date = '';
  Title = '';
  Department = '';
  Shera = '';

  constructor() { }

  ngOnInit() {}

  resetForm(){
    this.myForm.reset();
  }

}
