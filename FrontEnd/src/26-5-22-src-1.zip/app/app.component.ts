import { Component } from '@angular/core'
import {Router,NavigationStart} from '@angular/router';
import { MenuController,PopoverController } from '@ionic/angular';
import { PopoverComponent  } from './popover/popover.component'


@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  showHead: boolean = false;

  constructor(private router:Router,private menu: MenuController,public popoverController: PopoverController) {

    
    
    
    // on route change to '/login', set the variable showHead to false
    router.events.forEach((event) => {
      if (event instanceof NavigationStart) {
        if (event['url'] == '/login' || event['url'] == '/signup' || event['url'] == '/otp') {
          this.showHead = false;
        } else {
          // console.log("NU")
          this.showHead = true;
        }
      }
      
    });
  }

  async notifications(ev: any) {  
    const popover = await this.popoverController.create({  
        component: PopoverComponent,  
        event: ev,  
        animated: true,  
        showBackdrop: true ,
    });  
    return await popover.present();  
  }  
 
  logout(){
    this.router.navigate(['/login'])
  }

  

  
}
