import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-surnamewise-list',
  templateUrl: './surnamewise-list.component.html',
  styleUrls: ['./surnamewise-list.component.scss'],
})
export class SurnamewiseListComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
