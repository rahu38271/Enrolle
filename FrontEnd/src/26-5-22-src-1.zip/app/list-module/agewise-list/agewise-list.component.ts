import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agewise-list',
  templateUrl: './agewise-list.component.html',
  styleUrls: ['./agewise-list.component.scss'],
})
export class AgewiseListComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
