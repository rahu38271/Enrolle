import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-by-surname',
  templateUrl: './by-surname.component.html',
  styleUrls: ['./by-surname.component.scss'],
})
export class BySurnameComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
