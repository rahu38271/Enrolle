import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ListComponent } from './list/list.component'
import { ByVillageComponent } from './by-village/by-village.component'
import { VillagewiseListComponent } from './villagewise-list/villagewise-list.component'
import { ModernWayComponent } from './modern-way/modern-way.component'
import { ListwiseComponent } from './listwise/listwise.component'
import { BySurnameComponent } from './by-surname/by-surname.component'
import { SurnamewiseListComponent } from './surnamewise-list/surnamewise-list.component'
import { ByBoothComponent } from './by-booth/by-booth.component'
import { BoothwiseListComponent } from './boothwise-list/boothwise-list.component'
import { ByListComponent } from './by-list/by-list.component'
import {  ListwiseListComponent} from './listwise-list/listwise-list.component'
import { AgewiseListComponent } from './agewise-list/agewise-list.component'
import {ByCastComponent } from './by-cast/by-cast.component'
import {CastwiseListComponent } from './castwise-list/castwise-list.component'

@NgModule({
  declarations: [ListComponent,ByVillageComponent,VillagewiseListComponent,ModernWayComponent,ListwiseComponent,BySurnameComponent,SurnamewiseListComponent,ByBoothComponent,BoothwiseListComponent,ByListComponent,ListwiseListComponent,AgewiseListComponent,ByCastComponent,CastwiseListComponent],
  imports: [
    CommonModule,
    IonicModule,
    FormsModule,
    RouterModule.forChild([{path:'', component:ListComponent}, {path:'by-village', component:ByVillageComponent},{path:'villagewise-list', component:VillagewiseListComponent},{path:'modern-way', component:ModernWayComponent},{path:'listwise', component:ListwiseComponent},{path:'by-surname', component:BySurnameComponent},{path:'surnamewise-list', component:SurnamewiseListComponent},{path:'by-booth', component:ByBoothComponent},{path:'boothwise-list', component:BoothwiseListComponent},{path:'by-list', component:ByListComponent},{path:'listwise-list', component:ListwiseListComponent},{path:'agewise-list', component:AgewiseListComponent},{path:'by-cast', component:ByCastComponent},{path:'castwise-list', component:CastwiseListComponent}])
  ]
})
export class ListModuleModule { }
