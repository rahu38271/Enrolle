import { Component, OnInit } from '@angular/core';
import { LoadingController } from '@ionic/angular';



@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.scss'],
})
export class AddUserComponent implements OnInit {
  myForm;
  Database = '';
  State = '';
  VidhanSabha = '';
  Route = '';
  Username = '';
  Password = '';
  Id = '';
  Candidate = '';
  Quote = '';
  smsUsername = '';
  SMSPassword = '';
  Role = '';
  Booth = '';
  Email = '';
  SA_createUser = '';
  A_createUser = '';
  U_createUser = '';

  DatabaseHeader:any = {
    header: 'Select Database'
  }

  StateHeader: any = {
    header: 'Select State'
  }
  VidhanSabhaHeader: any = {
    header: 'Select VidhanSabha',
    cssClass: 'select-width',
  }
  RouteHeader: any = {
    header: 'Select Route'
  }

  RoleHeader: any = {
    header: 'Select User Role'
  }
  BoothHeader: any = {
    header: 'Select Booth'
  }

  private selectedOption: string;

  options = [
    { name: "first", value: 1 },
    { name: "two", value: 2 }
  ]
  
  keyPressNumbers(event) {
    var charCode = (event.which) ? event.which : event.keyCode;
    // Only Numbers 0-9
    if ((charCode < 48 || charCode > 57)) {
      event.preventDefault();
      return false;
    } else {
      return true;
    }
  }

  onKeyPress(event) {
    if ((event.keyCode >= 65 && event.keyCode <= 90) || (event.keyCode >= 97 && event.keyCode <= 122) || event.keyCode == 32 || event.keyCode == 46) {
        return true
    }
    else {
        return false
    }
}

  constructor(public loadingController: LoadingController) { }

  ismyTextFieldType: boolean;
  togglemyPasswordFieldType(){
    this.ismyTextFieldType = !this.ismyTextFieldType;
  }

  async presentLoading() {
    const loading = await this.loadingController.create({
      cssClass: 'my-custom-class',
      message: 'Adding User...',
      duration: 2000
    });
    await loading.present();

    const { role, data } = await loading.onDidDismiss();
    console.log('Loading dismissed!');
  }

  ngOnInit() {}

  resetForm(){
    this.myForm.reset();
  }

}
