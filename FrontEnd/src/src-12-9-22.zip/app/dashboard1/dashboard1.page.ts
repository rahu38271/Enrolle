import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard1',
  templateUrl: './dashboard1.page.html',
  styleUrls: ['./dashboard1.page.scss'],
})
export class Dashboard1Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
