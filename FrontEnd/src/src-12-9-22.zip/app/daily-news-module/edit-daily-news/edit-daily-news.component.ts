import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-daily-news',
  templateUrl: './edit-daily-news.component.html',
  styleUrls: ['./edit-daily-news.component.scss'],
})
export class EditDailyNewsComponent implements OnInit {

  modeHeader:any = {
    header: 'माध्यम'
  }
  modetypeHeader:any = {
    header: 'माध्यमाचे नाव'
  }
  journalistHeader:any = {
    header: 'पत्रकार'
  }

  myForm;
  
  subject = '';
  link = '';
  reporter = '';
  modeType = '';
  mode = '';

  constructor() { }

  ngOnInit() {}

  resetForm(){
    this.myForm.reset();
  }

}
