import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listwise-list',
  templateUrl: './listwise-list.component.html',
  styleUrls: ['./listwise-list.component.scss'],
})
export class ListwiseListComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
