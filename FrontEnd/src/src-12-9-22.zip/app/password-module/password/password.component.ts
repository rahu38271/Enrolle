import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-password',
  templateUrl: './password.component.html',
  styleUrls: ['./password.component.scss'],
})
export class PasswordComponent implements OnInit {

  myForm;

  passwordModel: any = {};
 
  Password = '';

  constructor() { }

  passwordField: boolean;
  confirmpasswordField: boolean;
  password(){
    this.passwordField = !this.passwordField;
  }

  cPassword(){
    this.confirmpasswordField = !this.confirmpasswordField;
  }

  onSubmit(){
    if(this.passwordModel.invalid){
      return;
    }
  }

  ngOnInit() {}

  resetForm(){
    this.myForm.reset();
  }

}
