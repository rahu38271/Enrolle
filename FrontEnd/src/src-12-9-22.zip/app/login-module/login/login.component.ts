import { Component, OnInit } from '@angular/core';
import { Router, } from '@angular/router';
import { MenuController, ModalController } from '@ionic/angular';
import { IonicToastService } from 'src/app/services/ionic-toast.service';
import { AuthenticationService } from 'src/app/services/authentication.service'
import { OtpPage } from 'src/app/otp/otp.page';
import { LoaderService } from 'src/app/services/loader.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {

  generatedOtp:any;

  loginModal:any= {
    Username:'',
    Password:''
  };

  otpIsCheck:any = 0;

  slideOpts = {
    initialSlide: 0,
    speed: 400,
    autoplay: true
  };

  keyPressNumbers(event) {
    var charCode = (event.which) ? event.which : event.keyCode;
    // Only Numbers 0-9
    if ((charCode < 48 || charCode > 57)) {
      event.preventDefault();
      return false;
    } else {
      return true;
    }
  }

  onKeyPress(event) {
    if ((event.keyCode >= 65 && event.keyCode <= 90) || (event.keyCode >= 97 && event.keyCode <= 122) || event.keyCode == 32 || event.keyCode == 46) {
      return true
    }
    else {
      return false
    }
  }

  constructor(
    private router: Router,
    public menuCtrl: MenuController,
    private toast: IonicToastService,
    private auth: AuthenticationService,
    public modalController: ModalController,
    private loader: LoaderService
  ) {

  }

  ionViewWillEnter() {
    this.menuCtrl.enable(false);
  }

  ismyTextFieldType: boolean;
  togglemyPasswordFieldType() {
    this.ismyTextFieldType = !this.ismyTextFieldType;
  }


  ngOnInit() {

  }

  // onSubmit(f: NgForm) {
  //   if(this.loginModal.invalid){
  //       this.toast.presentToast("Invalid Username or Password", "danger")
  //       console.log("Invalid User");
  //   }
  //   f.resetForm();
  // }

  login() {

    this.auth.loginUser(this.loginModal.Username, this.loginModal.Password).subscribe(data => {
      if (typeof data==="object") {
        this.auth.sendOtp(this.loginModal.Username).subscribe((data) => {
           this.otpverify(data);
        });
      }
      else {
        this.toast.presentToast("Invalid Username or Password", "danger", 'alert-circle-outline')
        console.log("Invalid User");
      }
    });
  }



  async otpverify(otp:any) {
    debugger;
    const modal = await this.modalController.create({
      component: OtpPage,
      componentProps: {
        'otp': otp,
      },
      showBackdrop: true,
      backdropDismiss: false,
      cssClass: 'my-custom-class',
      swipeToClose: true,
      canDismiss: true,
      presentingElement: await this.modalController.getTop(),
    });
    modal.onDidDismiss().then((modelData) => {
      this.loader.showLoading();
      if (modelData !== null) {
        if (modelData.data.status) {
          this.otpIsCheck = 1 // valid otp
          this.loader.hideLoader();
          this.router.navigate(['/home/mobile-dashboard']);
          this.toast.presentToast("Logged In Succesfully", "success", 'checkmark-circle-outline')
        }
        else {
          this.loader.hideLoader();
          this.toast.presentToast("Invalid OTP!", "danger", 'alert-circle-outline');
        }
      }

    });
    return await modal.present();
  }

}
 