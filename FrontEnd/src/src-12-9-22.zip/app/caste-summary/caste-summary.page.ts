import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-caste-summary',
  templateUrl: './caste-summary.page.html',
  styleUrls: ['./caste-summary.page.scss'],
})
export class CasteSummaryPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
