import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MenuController,ModalController } from '@ionic/angular';

@Component({
  selector: 'app-otp',
  templateUrl: './otp.page.html',
  styleUrls: ['./otp.page.scss'],
})
export class OtpPage implements OnInit {

  @Input() otp :any
  enteredOtp;

  otpModel: any = {}

  config = {
    length:4,
    allowNumbersOnly: true,
    placeholder:'-',
    inputStyles:{
      'background': '#fafafa',
    },
    autoFocus:true
  }

  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  onOtpChange(e:any)
  {
    this.enteredOtp = e;
  }

  dismiss(status:any) {
    this.modalController.dismiss({
      'status': status
    });
  }

  constructor(private router:Router, public menuCtrl: MenuController, private modalController: ModalController) { }

  ngOnInit() {}

  Verify(){
    if(this.otp == this.enteredOtp){
      this.dismiss(true);
    }
    else{
      this.dismiss(false);
    }
  }

  ionViewWillEnter() {
    this.menuCtrl.enable(false);
  }

}
