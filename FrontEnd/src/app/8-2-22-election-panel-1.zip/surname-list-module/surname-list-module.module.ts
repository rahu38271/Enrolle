import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'
import { IonicModule} from '@ionic/angular'
import { RouterModule} from '@angular/router'
import { SurnameComponent } from './surname/surname.component'
import { SurnameDetailsComponent } from './surname-details/surname-details.component'
import { EditSurnameDetailsComponent } from './edit-surname-details/edit-surname-details.component'

@NgModule({
  declarations: [SurnameComponent,SurnameDetailsComponent,EditSurnameDetailsComponent],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild([{path:'', component:SurnameComponent },{path:'surname-details', component:SurnameDetailsComponent },{path:'edit-details', component:EditSurnameDetailsComponent }])
  ]
})
export class SurnameListModuleModule { }
