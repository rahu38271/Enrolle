import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-surname-details',
  templateUrl: './edit-surname-details.component.html',
  styleUrls: ['./edit-surname-details.component.scss'],
})
export class EditSurnameDetailsComponent implements OnInit {

  FheadHeader:any = {
    header: 'Is Family Head '
  }

  Sheader:any = {
    header: 'Is Suspicious'
  }

  stationHeader:any = {
    header: 'Is Out Station'
  }

  conditionHeader:any = {
    header: 'Alive/Dead'
  }

  occupationHeader:any = {
    header: 'Occupation'
  }

  KaryakartaHeader:any = {
    header: 'Karyakarta'
  }

  CasteHeader:any = {
    header: 'Caste'
  }

  InclinationHeader:any = {
    header: 'Voting Inclination'
  }

  PartyHeader:any = {
    header: 'Political Party'
  }
  
  
  myForm;
  
  surname = '';
  FMname = '';
  Rname = '';
  Age = '';
  Seriel = '';
  gender = '';
  house = '';
  booth = '';
  address = '';
  Fhead = '';
  Suspicious = '';
  Station = '';
  Mobile = '';
  Condition = '';
  Occupation = '';
  Remark = '';
  Oaddress = '';
  Karyakarta = ''
  Caste = '';
  Inclination = '';
  Party = '';

  constructor() { }

  ngOnInit() {}

  resetForm(){
    this.myForm.reset();
  }

}
