import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-beneficiaries',
  templateUrl: './add-beneficiaries.component.html',
  styleUrls: ['./add-beneficiaries.component.scss'],
})
export class AddBeneficiariesComponent implements OnInit {

  statusHeader:any = {
    header: 'सद्यस्थिती '
  }
  preferenceHeader: any = {
    header: 'प्राधान्य'
  }

  yojna:any = {
    header: 'योजना'
  }

  area:any = {
    header: 'एरिया'
  }
  occupation :any = {
    header: 'व्यवसाय'
  }

  status :any = {
    header: 'सद्यस्थिती'
  }

  myForm;
  Yojna = '';
  Name = '';
  Date = '';
  Area = '';
  Occupation = '';
  Mobile = '';
  Wmobile = '';
  Status = '';
  NameBy = '';
  MobileBy = '';
  Gammount = '';

  constructor() { }

  ngOnInit() {}

  resetForm(){
    this.myForm.reset();
  }

}
