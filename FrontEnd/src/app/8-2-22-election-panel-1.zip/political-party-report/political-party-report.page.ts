import { Component, OnInit } from '@angular/core';
import { IAccTooltipRenderEventArgs, IPointEventArgs } from '@syncfusion/ej2-angular-charts';

@Component({
  selector: 'app-political-party-report',
  templateUrl: './political-party-report.page.html',
  styleUrls: ['./political-party-report.page.scss'],
})
export class PoliticalPartyReportPage implements OnInit {

  public primaryXAxis: Object;
  public chartData: Object[];
  public piedata: Object[];
  public datalabel: Object;
  public tooltip: Object;
  public title: String;
  public pointClick(args: IPointEventArgs): void {
    document.getElementById("lbl").innerText = "X : " + args.point.x + "\nY : " + args.point.y;
  };

  constructor() { }

  ngOnInit() {
    this.chartData = [
      { party: 'Unassigned', count: 25891 }, { party: 'BJP', count: 3 },
      { party: 'NCP', count: 1 }, { party: 'Other', count: 1 },
    ];
    this.primaryXAxis = {
      valueType: 'Category'
    };

    this.datalabel = { visible: true };
    this.tooltip = { enable: true };
    this.title = 'Political Party Summary';
    this.piedata = [
      { 'x': 'Unassigned', y: 25891 }, { 'x': 'BJP', y: 3 },
      { 'x': 'NCP', y: 1 }, { 'x': 'Other', y: 1 },
    ];

  }

}
