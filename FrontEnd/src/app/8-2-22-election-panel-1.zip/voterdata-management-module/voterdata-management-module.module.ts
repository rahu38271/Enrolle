import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {IonicModule } from '@ionic/angular'
import { FormsModule } from '@angular/forms'
import {RouterModule } from '@angular/router'
import { VoterdataManagementComponent} from './voterdata-management/voterdata-management.component'
import { MatTableModule } from '@angular/material/table'
import { MatFormFieldModule  } from '@angular/material/form-field' 
import { MatPaginatorModule } from '@angular/material/paginator'
import { MatInputModule } from '@angular/material/input';



@NgModule({
  declarations: [VoterdataManagementComponent],
  imports: [
    CommonModule,
    IonicModule,
    FormsModule,
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    MatPaginatorModule,
    RouterModule.forChild([{path:'', component:VoterdataManagementComponent}])
  ]
})
export class VoterdataManagementModuleModule { }
