import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-voterdata',
  templateUrl: './edit-voterdata.component.html',
  styleUrls: ['./edit-voterdata.component.scss'],
})
export class EditVoterdataComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
