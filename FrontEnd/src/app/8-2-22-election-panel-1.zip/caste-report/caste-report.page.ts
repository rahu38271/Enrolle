import { Component, OnInit } from '@angular/core';
import { IAccTooltipRenderEventArgs, IPointEventArgs } from '@syncfusion/ej2-angular-charts';

@Component({
  selector: 'app-caste-report',
  templateUrl: './caste-report.page.html',
  styleUrls: ['./caste-report.page.scss'],
})
export class CasteReportPage implements OnInit {

  public primaryXAxis: Object;
  public chartData: Object[];
  public piedata: Object[];
  public datalabel: Object;
  public tooltip: Object;
  public title: String;
  public pointClick(args: IPointEventArgs): void {
    document.getElementById("lbl").innerText = "X : " + args.point.x + "\nY : " + args.point.y;
  };

  constructor() { }

  ngOnInit() {
    this.chartData = [
      { caste: 'Unassigned', count: 25890 }, { caste: 'Baniya', count: 2 },
      { caste: 'Bari', count: 1 }, { caste: 'Buddha', count: 1 },
      { caste: 'Jain', count: 1 },{ caste: 'Maratha', count: 1 },
    ];
    this.primaryXAxis = {
      valueType: 'Category'
    };

    this.datalabel = { visible: true };
    this.tooltip = { enable: true };
    this.title = 'Inclination Summary';
    this.piedata = [
      { 'x': 'Unassigned', y: 25890 }, { 'x': 'Baniya', y: 2 },
      { 'x': 'Bari', y: 1 },{ 'x': 'Buddha', y: 1 }, 
      { 'x': 'Jain', y: 1 },{ 'x': 'Maratha', y: 1 },
    ];

  }

}
