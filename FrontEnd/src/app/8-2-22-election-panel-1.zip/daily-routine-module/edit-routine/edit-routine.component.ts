import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-routine',
  templateUrl: './edit-routine.component.html',
  styleUrls: ['./edit-routine.component.scss'],
})
export class EditRoutineComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
