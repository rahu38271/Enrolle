import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { AlertController } from '@ionic/angular';
import * as xlsx from 'xlsx';
import html2pdf from 'html2pdf.js'

@Component({
  selector: 'app-daily-news',
  templateUrl: './daily-news.component.html',
  styleUrls: ['./daily-news.component.scss'],
})
export class DailyNewsComponent implements OnInit {

  @ViewChild('epltable', { static: false }) epltable: ElementRef;

  
  myForm1: any;
  Mode = '';
  ModeName = '';
  Journalist = '';
  Date = '';
  Against = '';
  Other = '';

  designation: any = {
    header: 'पदनाम'
  };

  village: any = {
    header: 'गावाचे नाव'
  };

  constructor(public alertController: AlertController) { }

  ngOnInit() {
    $('#table10').DataTable({
      lengthMenu: [ [25, 50, 100, -1], [25, 50, 100, "All"] ],
      pageLength: 25,
      autoWidth: false,
      "columnDefs": [
        { "width": "20px", "targets": 0 },
        { "width": "20px", "targets": 1 },
        { "width": "100px", "targets": 2 },
        { "width": "200px", "targets": 3 },
        { "width": "100px", "targets": 4 },
        { "width": "100px", "targets": 5 },
        { "width": "100px", "targets": 6 },
        { "width": "100px", "targets": 7 },
      ],
    });
  }

  resetForm(){
    this.myForm1.reset();
  }

  async deleteNews() {
    const alert = await this.alertController.create({
      header: 'Delete दैनंदिन बातम्या ?',
      message: 'Are you sure want to delete this दैनंदिन बातम्या',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Yes',
          cssClass: 'deleteBtn',
          handler: () => {
            console.log('Confirm Ok');
          }
        }
      ],
    });

    await alert.present();
  }


  exportexcel() {
    const ws: xlsx.WorkSheet =
      xlsx.utils.table_to_sheet(this.epltable.nativeElement);
    const wb: xlsx.WorkBook = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(wb, ws, 'Sheet1');
    xlsx.writeFile(wb, 'epltable.xlsx');
  }

  pdf() {
    var element = document.getElementById('table10');
    
    var opt = {
      margin: 0.2,
      filename: 'myfile.pdf',
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
    };

    // New Promise-based usage:
    html2pdf().set(opt).from(element).save();{};

    // Old monolithic-style usage:
    html2pdf(element, opt);
  }

}
