import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { AlertController } from '@ionic/angular';
import * as xlsx from 'xlsx';
import html2pdf from 'html2pdf.js'

@Component({
  selector: 'app-office-directory',
  templateUrl: './office-directory.component.html',
  styleUrls: ['./office-directory.component.scss'],
})
export class OfficeDirectoryComponent implements OnInit {

  myForm1: any;
  Designation = '';
  Department = '';
  Postload = '';
  Mobile = '';
  Name = '';

  designation: any = {
    header: 'पदनाम'
  };

  department: any = {
    header: 'विभाग'
  };

  keyPressNumbers(event) {
    var charCode = (event.which) ? event.which : event.keyCode;
    // Only Numbers 0-9
    if ((charCode < 48 || charCode > 57)) {
      event.preventDefault();
      return false;
    } else {
      return true;
    }
  }

  onKeyPress(event) {
    if ((event.keyCode >= 65 && event.keyCode <= 90) || (event.keyCode >= 97 && event.keyCode <= 122) || event.keyCode == 32 || event.keyCode == 46) {
        return true
    }
    else {
        return false
    }
}

  @ViewChild('epltable', { static: false }) epltable: ElementRef;

  constructor(public alertController: AlertController) { }

  resetForm(){
    this.myForm1.reset();
  }

  ngOnInit() {
    $('#table7').DataTable({
      lengthMenu: [ [25, 50, 100, -1], [25, 50, 100, "All"] ],
      pageLength: 25,
      autoWidth: false,
      "columnDefs": [
        { "width": "20px", "targets": 0 },
        { "width": "150px", "targets": 1 },
        { "width": "150px", "targets": 2 },
        { "width": "100px", "targets": 3 },
        { "width": "100px", "targets": 4 },
        { "width": "50px", "targets": 5 },
      ],
    });
   }

  async deleteOfficer() {
    const alert = await this.alertController.create({
      header: 'Delete ऑफिसर ?',
      message: 'Are you sure want to delete this ऑफिसर',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Yes',
          cssClass: 'deleteBtn',
          handler: () => {
            console.log('Confirm Ok');
          }
        }
      ],
    });

    await alert.present();
  }


  exportexcel() {
    const ws: xlsx.WorkSheet =
      xlsx.utils.table_to_sheet(this.epltable.nativeElement);
    const wb: xlsx.WorkBook = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(wb, ws, 'Sheet1');
    xlsx.writeFile(wb, 'epltable.xlsx');
  }

  pdf() {
    var element = document.getElementById('table7');
    
    var opt = {
      margin: 0.2,
      filename: 'myfile.pdf',
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
    };

    // New Promise-based usage:
    html2pdf().set(opt).from(element).save();{};

    // Old monolithic-style usage:
    html2pdf(element, opt);
  }

}
