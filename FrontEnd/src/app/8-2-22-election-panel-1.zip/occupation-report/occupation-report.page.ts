import { Component, OnInit } from '@angular/core';
import { IAccTooltipRenderEventArgs, IPointEventArgs } from '@syncfusion/ej2-angular-charts';


@Component({
  selector: 'app-occupation-report',
  templateUrl: './occupation-report.page.html',
  styleUrls: ['./occupation-report.page.scss'],
})
export class OccupationReportPage implements OnInit {

  public primaryXAxis: Object;
  public chartData: Object[];
  public piedata: Object[];
  public datalabel: Object;
  public tooltip: Object;
  public title: String;
  public pointClick(args: IPointEventArgs): void {
    document.getElementById("lbl").innerText = "X : " + args.point.x + "\nY : " + args.point.y;
  };

  constructor() { }

  ngOnInit() {
    this.chartData = [
      { occupation: 'Unassigned', count: 25891 }, { occupation: 'Business', count: 1 },
      { occupation: 'Engineer', count: 1 }, { occupation: 'Housewife', count: 1 },
      { occupation: 'Other', count: 1 }, { occupation: 'Social Worker', count: 1 },
    ];
    this.primaryXAxis = {
      valueType: 'Category'
    };

    this.datalabel = { visible: true };
    this.tooltip = { enable: true };
    this.title = 'Occupation Summary';
    this.piedata = [
      { 'x': 'Unassigned', y: 25891 }, { 'x': 'Business', y: 1 },
      { 'x': 'Engineer', y: 1 }, { 'x': 'Housewife', y: 1 },
      { 'x': 'Other', y: 1 }, { 'x': 'Social Worker', y: 1 },
    ];

  }

}
