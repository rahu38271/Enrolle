import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-govt-rules',
  templateUrl: './edit-govt-rules.component.html',
  styleUrls: ['./edit-govt-rules.component.scss'],
})
export class EditGovtRulesComponent implements OnInit {

  departmentHeader:any = {
    header: 'संबंधित विभाग '
  }
  typeHeader: any = {
    header: 'प्रकार'
  }

  modeType:any = {
    header: 'माध्यमाचे नाव'
  }

  myForm;
  message = ''
  subject = '';
  serielNumber = '';
  
  department = '';

  constructor() { }

  ngOnInit() {}

  resetForm(){
    this.myForm.reset();
  }

}
