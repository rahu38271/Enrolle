import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-voter-inclination-list',
  templateUrl: './voter-inclination-list.page.html',
  styleUrls: ['./voter-inclination-list.page.scss'],
})
export class VoterInclinationListPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
