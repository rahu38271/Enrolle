import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-other-directory',
  templateUrl: './add-other-directory.component.html',
  styleUrls: ['./add-other-directory.component.scss'],
})
export class AddOtherDirectoryComponent implements OnInit {

  myForm;
 
  mobile = '';
  office = '';
  name = '';
  home = '';
  email = '';
  floor = '';
  desk = '';
  assistant = '';
  Wmobile = '';
  designation = '';
  village = '';
  work = '';
  date = '';

  constructor() { }

  ngOnInit() {}

  resetForm(){
    this.myForm.reset();
  }

}
