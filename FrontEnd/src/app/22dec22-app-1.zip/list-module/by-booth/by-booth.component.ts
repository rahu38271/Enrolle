import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-by-booth',
  templateUrl: './by-booth.component.html',
  styleUrls: ['./by-booth.component.scss'],
})
export class ByBoothComponent implements OnInit {

  isShow = false;

  constructor() { }

  search(){
    this.isShow = !this.isShow
  }

  ngOnInit() {}

}
