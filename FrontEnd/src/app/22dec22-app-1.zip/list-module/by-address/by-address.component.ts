import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-by-address',
  templateUrl: './by-address.component.html',
  styleUrls: ['./by-address.component.scss'],
})
export class ByAddressComponent implements OnInit {

  isShow = false;

  constructor() { }

  search(){
    this.isShow = !this.isShow
  }

  ngOnInit() {

  }

}
