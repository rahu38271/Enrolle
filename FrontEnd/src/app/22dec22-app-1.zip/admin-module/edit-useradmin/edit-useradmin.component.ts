import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { LoadingController } from '@ionic/angular';
import { LoaderService } from 'src/app/services/loader.service'
import { IonicToastService} from 'src/app/services/ionic-toast.service'
import {UserService } from 'src/app/services/user.service'

@Component({
  selector: 'app-edit-useradmin',
  templateUrl: './edit-useradmin.component.html',
  styleUrls: ['./edit-useradmin.component.scss'],
})
export class EditUseradminComponent implements OnInit {

  userModel: any = {};
  myForm;
  EditData:any = {}
  
  keyPressNumbers(event) {
    var charCode = (event.which) ? event.which : event.keyCode;
    // Only Numbers 0-9
    if ((charCode < 48 || charCode > 57)) {
      event.preventDefault();
      return false;
    } else {
      return true;
    }
  }

  onKeyPress(event) {
    if ((event.keyCode >= 65 && event.keyCode <= 90) || (event.keyCode >= 97 && event.keyCode <= 122) || event.keyCode == 32 || event.keyCode == 46) {
        return true
    }
    else {
        return false
    }
}

  constructor
    (
      public loadingController: LoadingController,
      private loader:LoaderService,
      private toast:IonicToastService,
      private user:UserService
    ) 
    { }

  ismyTextFieldType: boolean;
  togglemyPasswordFieldType(){
    this.ismyTextFieldType = !this.ismyTextFieldType;
  }

  ngOnInit() {}

  save(){
    
   
  }

  resetForm(){
    this.myForm.reset();
  }

  onSubmit(f:NgForm){
    if(this.userModel.invalid){
      return;
    }else{

    }
    f.resetForm();
  }

}
