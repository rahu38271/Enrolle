import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { UseradminComponent } from './useradmin/useradmin.component';
import { AddUseradminComponent } from './add-useradmin/add-useradmin.component';
import { EditUseradminComponent } from './edit-useradmin/edit-useradmin.component';
import { AccountDetailsComponent } from './account-details/account-details.component';
import { IonSelectSearchLibModule } from 'ionic-select-search';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [UseradminComponent,AddUseradminComponent, EditUseradminComponent, AccountDetailsComponent ],
  imports: [
    CommonModule,
    IonicModule,
    FormsModule,
    HttpClientModule,
    IonSelectSearchLibModule,
    RouterModule.forChild([{path:'', component: UseradminComponent}, {path:'add-useradmin', component: AddUseradminComponent}, {path:'edit-useradmin', component: EditUseradminComponent}, {path:'account-details', component: AccountDetailsComponent}])
  ]
})
export class AdminModuleModule { }
