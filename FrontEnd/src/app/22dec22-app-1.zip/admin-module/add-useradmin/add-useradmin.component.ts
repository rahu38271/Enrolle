import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AssemblyService } from 'src/app/services/assembly.service'
import { UserService } from 'src/app/services/user.service'
import { LoaderService} from 'src/app/services/loader.service'
import {IonicToastService } from 'src/app/services/ionic-toast.service'

@Component({
  selector: 'app-add-useradmin',
  templateUrl: './add-useradmin.component.html',
  styleUrls: ['./add-useradmin.component.scss'],
})
export class AddUseradminComponent implements OnInit {

  addMAmodal: any = {};
  myForm;
  Quote;
  assemblyList: any;
  
  keyPressNumbers(event) {
    var charCode = (event.which) ? event.which : event.keyCode;
    // Only Numbers 0-9
    if ((charCode < 48 || charCode > 57)) {
      event.preventDefault();
      return false;
    } else {
      return true;
    }
  }

  onKeyPress(event) {
    if ((event.keyCode >= 65 && event.keyCode <= 90) || (event.keyCode >= 97 && event.keyCode <= 122) || event.keyCode == 32 || event.keyCode == 46) {
        return true
    }
    else {
        return false
    }
}

  constructor
    (
      private assembly:AssemblyService,
      private user:UserService,
      private loader:LoaderService,
      private toast:IonicToastService
    ) 
    { }

  ismyTextFieldType: boolean;
  togglemyPasswordFieldType(){
    this.ismyTextFieldType = !this.ismyTextFieldType;
  }

  getAssembly(){
    this.assembly.getAssemblyData().subscribe(data=>{
      if(data.length > 0){
        console.log(data);
        this.assemblyList = data;
      }
    })
  }

  ngOnInit() {
    this.getAssembly();
  }

  addMAdmin(){
    debugger;
    this.addMAmodal.Validity = Number(this.addMAmodal.Validity);
    this.loader.showLoading();
    this.user.addMAdminData(this.addMAmodal).subscribe(data=>{
      if(data){
        this.addMAmodal = {};
        this.loader.hideLoader();
        this.toast.presentToast("Masteradmin added successfully!", "success", 'checkmark-circle-sharp');
      }
      else{
        this.loader.hideLoader();
        this.toast.presentToast("Masteradmin not saved", "danger", 'alert-circle-sharp');
      }
    }, (err)=>{
      this.loader.hideLoader();
      this.toast.presentToast("Masteradmin not saved", "danger", 'alert-circle-sharp');
    })
  }

  

  resetForm(){
    this.myForm.reset();
  }

  onSubmit(f:NgForm){
    if(this.addMAmodal.invalid){
      return;
    }else{

    }
    f.resetForm();
  }

}
