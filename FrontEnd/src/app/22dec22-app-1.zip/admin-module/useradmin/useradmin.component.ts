import { Component, OnInit,ViewChild,ElementRef } from '@angular/core';
import * as xlsx from 'xlsx';
import html2pdf from 'html2pdf.js'
import { AlertController } from '@ionic/angular';
import { UserService } from 'src/app/services/user.service'
import { LoaderService } from 'src/app/services/loader.service'
import { Router} from '@angular/router'

@Component({
  selector: 'app-useradmin',
  templateUrl: './useradmin.component.html',
  styleUrls: ['./useradmin.component.scss'],
})
export class UseradminComponent implements OnInit {

  Template = '';
  Content = '';
  NormalMsg = '';
  whatsappMsg = '';
  isShow = false;
   
  
  TemplateHeader:any = {
    header: 'Select Template'
  }

  currentDate = new Date();
  getAllMAdmin: any;

  search(){
    this.isShow = !this.isShow
  }

  @ViewChild('epltable', { static: false }) epltable: ElementRef;

  constructor
    (
      public alertController: AlertController,
      private user:UserService,
      private loader:LoaderService,
      private router:Router
    ) 
    {

     }

    getMAdmin(){
      this.user.getAllMAdmin().subscribe(data=>{
        this.loader.showLoading();
        if(data != 0){
          this.getAllMAdmin = data;
          this.loader.hideLoader();
        }
        else{
          
        }
      })
    }

    EditMA(data:any){
      this.router.navigateByUrl('/useradmin/edit-useradmin', {state:data})
    }

  ngOnInit() {
    this.getMAdmin();
  }

  async deleteUser() {
    const alert = await this.alertController.create({
      header: ' Delete User ?',
      cssClass: 'alertHeader',
      message: 'Are you sure want to delete this user',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'no',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Delete',
          cssClass: 'yes',
          handler: () => {
            console.log('Confirm Ok');
          }
        }
      ],
    });

    await alert.present();
  }

  exportexcel() {
    const ws: xlsx.WorkSheet =
      xlsx.utils.table_to_sheet(this.epltable.nativeElement);
    const wb: xlsx.WorkBook = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(wb, ws, 'Sheet1');
    xlsx.writeFile(wb, 'users.xlsx');
  }

  // async downloadExcel() {
  //   const toast = await this.toastController.create({
  //     message: 'Request added to export.',
  //     duration: 2000,
  //     position: 'top',
  //     color: 'success',
  //   });
  //   toast.present();
  // }

  // async downloadPDF() {
  //   const toast = await this.toastController.create({
  //     message: 'Request added to download doc.',
  //     duration: 2000,
  //     position: 'top',
  //     color: 'primary',
  //   });
  //   toast.present();
  // }



}
