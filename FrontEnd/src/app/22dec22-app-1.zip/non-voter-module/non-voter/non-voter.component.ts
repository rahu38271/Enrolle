import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-non-voter',
  templateUrl: './non-voter.component.html',
  styleUrls: ['./non-voter.component.scss'],
})
export class NonVoterComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
