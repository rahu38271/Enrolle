import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-booth',
  templateUrl: './booth.page.html',
  styleUrls: ['./booth.page.scss'],
})
export class BoothPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
