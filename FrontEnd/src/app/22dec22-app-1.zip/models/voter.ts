export class Voter {
    fullName:string;
    village:string;
    age:number;
    gender:string;
    caste:string;
    votingCardNo:string;
    address:string;
    partNo:number;
    mobileNo:string;
    isAlive:string;
}