export interface login{
    Username:string;
    Password:string;
    name:string;
    contact:string;
    id:number;
}