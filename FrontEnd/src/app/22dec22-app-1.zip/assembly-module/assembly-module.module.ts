import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AssemblyComponent } from './assembly/assembly.component';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AddAssemblyComponent } from './add-assembly/add-assembly.component';
import { EditAssemblyComponent } from './edit-assembly/edit-assembly.component';
import { ImportAssemblyComponent } from './import-assembly/import-assembly.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AssemblyComponent,
    AddAssemblyComponent,
    EditAssemblyComponent,
    ImportAssemblyComponent
  ],
  imports: [
    CommonModule,
    IonicModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forChild([{path:'', component: AssemblyComponent}, {path:'add-assembly', component: AddAssemblyComponent}, {path:'edit-assembly', component: AddAssemblyComponent}, {path:'import-assembly', component: ImportAssemblyComponent}])
  ]
})
export class AssemblyModuleModule { }
