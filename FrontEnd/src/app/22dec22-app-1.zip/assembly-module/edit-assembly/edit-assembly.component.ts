import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-assembly',
  templateUrl: './edit-assembly.component.html',
  styleUrls: ['./edit-assembly.component.css']
})
export class EditAssemblyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
