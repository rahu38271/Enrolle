import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-mobiledata-group',
  templateUrl: './add-mobiledata-group.component.html',
  styleUrls: ['./add-mobiledata-group.component.scss'],
})
export class AddMobiledataGroupComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
