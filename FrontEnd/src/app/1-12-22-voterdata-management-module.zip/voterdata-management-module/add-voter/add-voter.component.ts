import { Component, OnInit } from '@angular/core';
import { LoadingController } from '@ionic/angular';
import { ContactService } from 'src/app/services/contact.service'

@Component({
  selector: 'app-add-voter',
  templateUrl: './add-voter.component.html',
  styleUrls: ['./add-voter.component.scss'],
})
export class AddVoterComponent implements OnInit {

  districtList:any;
  talukaList:any;

  addVoterModal:any = { };

  myForm;

  year : number = new Date().getFullYear();

  public BirthDate: Date;
  public Age: number;
 
  keyPressNumbers(event) {
    var charCode = (event.which) ? event.which : event.keyCode;
    // Only Numbers 0-9
    if ((charCode < 48 || charCode > 57)) {
      event.preventDefault();
      return false;
    } else {
      return true;
    }
  }

  onKeyPress(event) {
    if ((event.keyCode >= 65 && event.keyCode <= 90) || (event.keyCode >= 97 && event.keyCode <= 122) || event.keyCode == 32 || event.keyCode == 46) {
        return true
    }
    else {
        return false
    }
}

  constructor(public loadingController: LoadingController, private contact:ContactService) { }

  getDistrict(){
    this.contact.getDistrictData().subscribe((data)=>{
      if(data.length > 0){
        this.districtList = data;
      }
    }, err=>{
      
    })
  }

  getTaluka(dId:any){
    this.contact.getTalukaData(dId).subscribe((data)=>{
      this.addVoterModal.District = this.districtList.find(x => x.dId=dId).districtName;
      this.talukaList = data;
    })
  }

  ngOnInit() {
    this.getDistrict();
  }

  resetForm(){
    this.myForm.reset();
  }

  async presentLoading() {
    const loading = await this.loadingController.create({
      cssClass: 'my-custom-class',
      message: 'Saving Details...',
      duration: 2000
    });
    await loading.present();

    const { role, data } = await loading.onDidDismiss();
    console.log('Loading dismissed!');
  }

  public cal_Age(): void{
    if(this.BirthDate){
       //convert date again to type Date
       const bdate = new Date(this.BirthDate);
       const timeDiff = Math.abs(Date.now() - bdate.getTime() );
       this.Age = Math.floor((timeDiff / (1000 * 3600 * 24)) / 365);
    }
  }

}
