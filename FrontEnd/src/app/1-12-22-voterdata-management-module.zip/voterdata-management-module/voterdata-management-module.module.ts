import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {IonicModule } from '@ionic/angular'
import { FormsModule } from '@angular/forms'
import {RouterModule } from '@angular/router'
import { VoterdataManagementComponent} from './voterdata-management/voterdata-management.component'
import { EditVoterdataComponent } from './edit-voterdata/edit-voterdata.component'
import { AddVoterComponent } from './add-voter/add-voter.component'
import { ImportVoterdataComponent } from './import-voterdata/import-voterdata.component'
import { VoterDetailsComponent } from './voter-details/voter-details.component'
import { MatTableModule } from '@angular/material/table'
import { MatFormFieldModule  } from '@angular/material/form-field' 
import { MatPaginatorModule } from '@angular/material/paginator'
import { MatInputModule } from '@angular/material/input';
import { NgxDropzoneModule } from 'ngx-dropzone';
import { SocialSharing } from '@awesome-cordova-plugins/social-sharing/ngx';

@NgModule({
  declarations: [VoterdataManagementComponent,EditVoterdataComponent,AddVoterComponent,ImportVoterdataComponent,VoterDetailsComponent],
  imports: [
    CommonModule,
    IonicModule,
    FormsModule,
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    NgxDropzoneModule,
    MatPaginatorModule,
    RouterModule.forChild([{path:'', component:VoterdataManagementComponent},{path:'edit-voterdata', component:EditVoterdataComponent},{path:'add-voter', component:AddVoterComponent},{path:'import-voter', component:ImportVoterdataComponent},{path:'voter-details', component:VoterDetailsComponent}])
  ],
  providers: [SocialSharing]
})
export class VoterdataManagementModuleModule { }
