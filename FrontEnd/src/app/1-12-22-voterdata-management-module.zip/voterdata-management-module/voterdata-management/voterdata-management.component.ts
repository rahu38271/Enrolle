import { Component, AfterViewInit, ViewChild,ElementRef } from '@angular/core';
import { LoadingController,ToastController } from '@ionic/angular';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import * as xlsx from 'xlsx';
import html2pdf from 'html2pdf.js'

export interface UserData {
  id: string;
  nameMar: string;
  booth: string;
  // nameEng: string;
  
  age: string;
  gender: string;
  votingcard: string;
  boothName: string;
  house: string;
  address: string;
  mobile: string;
  fruit: string;
}

/** Constants used to fill up our data base. */
const FRUITS: string[] = [
  'blueberry',
  'lychee',
  'kiwi',
  'mango',
  'peach',
  'lime',
  'pomegranate',
  'pineapple',
];

const MOBILE: string[] = [
  '9158490455', 
];

const BOOTH: string[] = [
  '334', 
];

const ADDRESS: string[] = [
  '17 D SARVANT QTR 18 N D A KHADAKWASALA PUNE PUNE PUNE PUNE MAHARASHTRA 411024', 
  'GHAR NAMBER 129 HAVELI SINHAGAD ROAD CITY DISTRICT PUNE STATE MAHARASHTRA UTTAM FLOAR MILCHYA MAGE CHARWAD AALI PUNE MAHARASHTRA 411024',
];
const GENDER: string[] = [
  'M', 
  'F',
];
const BOOTHNAME: string[] = [
  'जिल्हा परिषद शाळा, खडकवासला, उत्तरमुखी पूर्वेकडून खोली क्र.1', 
];
const HOUSE: string[] = [
  '', 
];

const VOTINGCARD: string[] = [
  'UVP2073229', 
  'UVP3820081',
  'UVP3923125',
  'UVP7062359',
];

const AGE: string[] = [
  '34',
  '31',
  '22', 
  '57',
];

// const NAMESE: string[] = [
//   'Abike Mukul Dattatreya',
//   'Bagarecha Raghunath Manaramji',
//   'Bagarecha Manisha Raghunatharam',
//   'Bagul Vijay Ramdas',
// ];

const NAMESM: string[] = [
  'अबिके मुकुल दत्तात्रय',
  'बगरेचा रघुनाथ मानारामजी',
  'बगरेचा मनिषा रघुनाथराम',
  'बागूल विजय रामदास',
];

/**
 * @title Data table with sorting, pagination, and filtering.
 */


@Component({
  selector: 'app-voterdata-management',
  templateUrl: './voterdata-management.component.html',
  styleUrls: ['./voterdata-management.component.scss'],
})
export class VoterdataManagementComponent implements AfterViewInit {

  myForm1: any;
  Bdate = '';
  area = '';
  Bgroup = '';
  ageFrom = '';
  ageTo = '';
  Name = '';
  FatherHusband = '';
  Surname = '';
  VotingCard = '';
  Gender = '';
  karyakarta = '';
  MobileNumber = '';

  isShow = false;
   
  search(){
    this.isShow = !this.isShow
  }

  matchHeader: any = {
    header: 'Matched/NotMatched'
  };

  mobileGroup: any = {
    header: 'Mobile Group'
  };

  GenderHeader: any = {
    header: 'Select Gender'
  }

  karyakartaHeader: any = {
    header: 'Select Karyakarta'
  }

  async downloadExcel() {
    const toast = await this.toastController.create({
      message: 'Request added to export.',
      duration: 2000,
      position: 'top',
      color: 'success',
    });
    toast.present();
  }

  async downloadPDF() {
    const toast = await this.toastController.create({
      message: 'Request added to download doc.',
      duration: 2000,
      position: 'top',
      color: 'primary',
    });
    toast.present();
  }

  @ViewChild('epltable', { static: false }) epltable: ElementRef;

  displayedColumns: string[] = ['id','nameMar','booth','boothName', 'age','gender','house','votingcard','address','fruit'];
  dataSource: MatTableDataSource<UserData>;

  @ViewChild(MatPaginator) paginator: MatPaginator; 
  @ViewChild(MatSort) sort: MatSort;

  onKeyPress(event) {
    if ((event.keyCode >= 65 && event.keyCode <= 90) || (event.keyCode >= 97 && event.keyCode <= 122) || event.keyCode == 32 || event.keyCode == 46) {
        return true
    }
    else {
        return false
    }
}

keyPressNumbers(event) {
  var charCode = (event.which) ? event.which : event.keyCode;
  // Only Numbers 0-9
  if ((charCode < 48 || charCode > 57)) {
    event.preventDefault();
    return false;
  } else {
    return true;
  }
}

  constructor(public loadingController: LoadingController,public toastController: ToastController) {
    // Create 100 users
    const users = Array.from({length: 100}, (_, k) => createNewUser(k + 1));

    // Assign the data to the data source for the table to render
    this.dataSource = new MatTableDataSource(users);
   }

   resetForm(){
    this.myForm1.reset();
  }

  async presentLoading() {
    const loading = await this.loadingController.create({
      cssClass: 'my-custom-class',
      message: 'Searching...',
      duration: 2000
    });
    await loading.present();

    const { role, data } = await loading.onDidDismiss();
    console.log('Loading dismissed!');
  }

   exportExcel() {
    const ws: xlsx.WorkSheet =
      xlsx.utils.table_to_sheet(this.epltable.nativeElement);
    const wb: xlsx.WorkBook = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(wb, ws, 'Sheet1');
    xlsx.writeFile(wb, 'epltable.xlsx');
  }

  pdf() {
    var element = document.getElementById('table');
    
    var opt = {
      margin: 0.5,
      filename: 'myfile.pdf',
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: 'in', format: 'letter', orientation: 'landscape' }
    };

    // New Promise-based usage:
    html2pdf().set(opt).from(element).save();{};

    // Old monolithic-style usage:
    html2pdf(element, opt);
  }

   ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  

}

/** Builds and returns a new User. */
function createNewUser(id: number): UserData {
  // const nameEng =
  //   NAMESE[Math.round(Math.random() * (NAMESE.length - 1))] +
  //   ' ' +
  //   NAMESE[Math.round(Math.random() * (NAMESE.length - 1))].charAt(0) +
  //   '.';

    const nameMar =
    NAMESM[Math.round(Math.random() * (NAMESM.length - 1))] +
    ' ' +
    NAMESM[Math.round(Math.random() * (NAMESM.length - 1))].charAt(0) +
    '.';

  return {
    id: id.toString(),
    // nameEng: nameEng,
    nameMar: nameMar,
    fruit: FRUITS[Math.round(Math.random() * (FRUITS.length - 1))],
    booth: BOOTH[Math.round(Math.random() * (BOOTH.length - 1))],
    age: AGE[Math.round(Math.random() * (AGE.length - 1))],
    gender: GENDER[Math.round(Math.random() * (GENDER.length - 1))],
    votingcard: VOTINGCARD[Math.round(Math.random() * (VOTINGCARD.length - 1))],
    boothName: BOOTHNAME[Math.round(Math.random() * (BOOTHNAME.length - 1))],
    house: HOUSE[Math.round(Math.random() * (HOUSE.length - 1))],
    address: ADDRESS[Math.round(Math.random() * (ADDRESS.length - 1))],
    mobile: MOBILE[Math.round(Math.random() * (MOBILE.length - 1))],
  };
}