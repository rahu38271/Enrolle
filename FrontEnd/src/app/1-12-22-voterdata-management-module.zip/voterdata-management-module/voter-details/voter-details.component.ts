import { Component, OnInit, ViewChild } from '@angular/core';
import { PDFGenerator } from '@ionic-native/pdf-generator/ngx';
import { SocialSharing } from '@awesome-cordova-plugins/social-sharing/ngx';
import { IonModal } from '@ionic/angular';
import { OverlayEventDetail } from '@ionic/core/components';

@Component({
  selector: 'app-voter-details',
  templateUrl: './voter-details.component.html',
  styleUrls: ['./voter-details.component.scss'],
})
export class VoterDetailsComponent implements OnInit {

  @ViewChild(IonModal) modal: IonModal;

  isStar:boolean;
  
  toggleStar(){
    this.isStar = !this.isStar;
  }


  message = 'This modal example uses triggers to automatically open a modal when the button is clicked.';
  name: string;

  cancel() {
    this.modal.dismiss(null, 'cancel');
  }

  confirm() {
    this.modal.dismiss(this.name, 'confirm');
  }

  onWillDismiss(event: Event) {
    const ev = event as CustomEvent<OverlayEventDetail<string>>;
    if (ev.detail.role === 'confirm') {
      this.message = `Hello, ${ev.detail.data}!`;
    }
  }

  mobiles: number [] = [];
  wapps: number [] = [];
  emails: number [] = []; 
  addresses: number [] = [];
  content: string;

  constructor(private pdfGenerator: PDFGenerator, private socialSharing: SocialSharing,) { }

  ngOnInit() {}

  addMobile(){
    this.mobiles.push(this.mobiles.length);
  }
  removeMobile(){
    this.mobiles.pop();
  }
  addwapp(){
    this.wapps.push(this.wapps.length);
  }
  removewapp(){
    this.wapps.pop();
  }
  addEmail(){
    this.emails.push(this.emails.length);
  }
  removeEmail(){
    this.emails.pop();
  }
  addAddress(){
    this.addresses.push(this.addresses.length);
  }
  removeAddress(){
    this.addresses.pop();
  }

  printSlip(){
    this.content = document.getElementById('slipDesign').innerHTML;
    let options = {
      documentSize: 'a7',
      type: 'share',
      // landscape: 'portrait', 86mm x 54mm
      fileName: 'voter slip.pdf'
    };
    this.pdfGenerator.fromData(this.content, options)
      .then((base64) => {
        console.log('OK', base64);
      }).catch((error) => {
        console.log('error', error);
      });
    
  }

  share(){
    var options = {
      message: 'Share', // not supported on some apps (Facebook, Instagram)
       url: 'https://ionicframework.com/docs/native/social-sharing',
    };
    this.socialSharing.shareWithOptions(options);
  }

}
