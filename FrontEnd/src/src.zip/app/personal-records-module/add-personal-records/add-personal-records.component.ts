import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-personal-records',
  templateUrl: './add-personal-records.component.html',
  styleUrls: ['./add-personal-records.component.scss'],
})
export class AddPersonalRecordsComponent implements OnInit {

  priorityHeader:any = {
    header: 'प्राधान्य'
  }
  statusHeader: any = {
    header: 'सद्यस्थिती'
  }
  remFrequencyHeader:any = {
    header: ' रिमाइंडर वारंवारता'
  }

 

  myForm;
  message = ''
  subject = '';
  
  date1 = '';
 
  priority = '';
  status = '';
 

  constructor() { }

  ngOnInit() {}

  resetForm(){
    this.myForm.reset();
  }

}
