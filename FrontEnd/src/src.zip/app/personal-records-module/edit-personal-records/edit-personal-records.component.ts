import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-personal-records',
  templateUrl: './edit-personal-records.component.html',
  styleUrls: ['./edit-personal-records.component.scss'],
})
export class EditPersonalRecordsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
