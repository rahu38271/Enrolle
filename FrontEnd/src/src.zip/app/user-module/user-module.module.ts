import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { RouterModule } from '@angular/router'

import { AddUserComponent } from './add-user/add-user.component'
import { ViewUserComponent } from './view-user/view-user.component'

@NgModule({
  declarations: [ViewUserComponent,AddUserComponent],
  imports: [
    CommonModule,
    IonicModule,
    RouterModule.forChild([{path:'viewUser', component:ViewUserComponent}, {path:'addUser', component:AddUserComponent}])
  ]
})
export class UserModuleModule { }
