import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule),
  },
  {
    path: 'login',
    loadChildren: () => import('./login-module/login-module.module').then( m => m.LoginModuleModule)
  },
  {
    path: 'otp',
    loadChildren: () => import('./otp-module/otp-module.module').then( m => m.OtpModuleModule)
  },
  {
    path: 'user',
    loadChildren: () => import('./user-module/user-module.module').then( m => m.UserModuleModule)
  },
  {
    path: 'daily-routine',
    loadChildren: () => import('./daily-routine-module/daily-routine-module.module').then( m => m.DailyRoutineModuleModule)
  },
  {
    path: 'signup',
    loadChildren: () => import('./signup-module/signup-module.module').then( m => m.SignupModuleModule)
  },
  {
    path: 'karyakarta',
    loadChildren:() => import ('./karyakarta-module/karyakarta-module.module').then(m => m.KaryakartaModuleModule)
  },
  {
    path:'officer-directory',
    loadChildren:() => import ( './officer-directory-module/officer-directory-module.module' ).then (m => m.OfficerDirectoryModuleModule)
  },
  {
    path:'other-directory',
    loadChildren:() => import ( './other-directory-module/other-directory-module.module' ).then (m => m.OtherDirectoryModuleModule)
  },
  {
    path:'daily-news',
    loadChildren:() => import ( './daily-news-module/daily-news-module.module' ).then (m => m.DailyNewsModuleModule)
  },
  {
    path:'journalist',
    loadChildren:() => import ( './journalist-module/journalist-module.module' ).then (m => m.JournalistModuleModule)
  },
  {
    path:'press-note',
    loadChildren:() => import ( './press-note-module/press-note-module.module' ).then (m => m.PressNoteModuleModule)
  },
  {
    path:'appointment',
    loadChildren:() => import ( './appointment-module/appointment-module.module' ).then (m => m.AppointmentModuleModule)
  },
  {
    path:'beneficiaries',
    loadChildren:() => import ( './beneficiaries-module/beneficiaries-module.module' ).then (m => m.BeneficiariesModuleModule)
  },
  {
    path:'personal-records',
    loadChildren:() => import ( './personal-records-module/personal-records-module.module' ).then (m => m.PersonalRecordsModuleModule)
  },
  {
    path:'govt-rules',
    loadChildren:() => import ( './govt-rules-module/govt-rules-module.module' ).then (m => m.GovtRulesModuleModule)
  },
  {
    path:'document-repository',
    loadChildren:() => import ( './document-repository-module/document-repository-module.module' ).then (m => m.DocumentRepositoryModuleModule)
  },
  {
    path:'voter-summary',
    loadChildren:() => import ( './voter-summary-module/voter-summary-module.module' ).then (m => m.VoterSummaryModuleModule)
  },
  {
    path:'voterdata-management',
    loadChildren:() => import ( './voterdata-management-module/voterdata-management-module.module' ).then (m => m.VoterdataManagementModuleModule)
  },
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: 'todays-birthday',
    loadChildren: () => import('./todays-birthday/todays-birthday.module').then( m => m.TodaysBirthdayPageModule)
  },
  {
    path: 'daily-work',
    loadChildren: () => import('./daily-work/daily-work.module').then( m => m.DailyWorkPageModule)
  },
  {
    path: 'daily-news',
    loadChildren: () => import('./daily-news/daily-news.module').then( m => m.DailyNewsPageModule)
  },
  {
    path: 'daily-routine',
    loadChildren: () => import('./daily-routine/daily-routine.module').then( m => m.DailyRoutinePageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
