import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-journalist',
  templateUrl: './edit-journalist.component.html',
  styleUrls: ['./edit-journalist.component.scss'],
})
export class EditJournalistComponent implements OnInit {

  modeHeader:any = {
    header: 'माध्यम '
  }

  modeTypeHeader:any = {
    header: 'माध्यमाचे नाव'
  }

  myForm;
  
  subject = '';
  link = '';
  reporter = '';
  mobile = '';
  whatsapp = '';
  radio = '';
  mode= '';
  modeType ='';

  constructor() { }

  ngOnInit() {}

  resetForm(){
    this.myForm.reset();
  }
}
