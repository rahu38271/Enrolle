import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-routine',
  templateUrl: './add-routine.component.html',
  styleUrls: ['./add-routine.component.scss'],
})
export class AddRoutineComponent implements OnInit {
  myForm;
  program = '';
  type = '';
  place = '';
  address = '';
  radio = '';

  constructor() { }

  ngOnInit() {}

  RoutineForm(){

  }

  resetForm(){
    this.myForm.reset();
  }

}
