import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular'
import { FormsModule } from '@angular/forms'
import {RouterModule } from '@angular/router'
import { BeneficiariesComponent } from './beneficiaries/beneficiaries.component'
import { AddBeneficiariesComponent} from './add-beneficiaries/add-beneficiaries.component'
import { EditBeneficiariesComponent} from './edit-beneficiaries/edit-beneficiaries.component'

@NgModule({
  declarations: [BeneficiariesComponent,AddBeneficiariesComponent,EditBeneficiariesComponent],
  imports: [
    CommonModule,
    IonicModule,
    FormsModule,
    RouterModule.forChild([{path:'', component:BeneficiariesComponent}, { path:'add-beneficiaries', component:AddBeneficiariesComponent}, {path:'edit-beneficiaries', component:EditBeneficiariesComponent}])
  ]
})
export class BeneficiariesModuleModule { }
