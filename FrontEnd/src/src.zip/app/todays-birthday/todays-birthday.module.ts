import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { TodaysBirthdayPageRoutingModule } from './todays-birthday-routing.module';

import { TodaysBirthdayPage } from './todays-birthday.page';
import { DataTablesModule } from 'angular-datatables';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    TodaysBirthdayPageRoutingModule,
    DataTablesModule
  ],
  declarations: [TodaysBirthdayPage]
})
export class TodaysBirthdayPageModule {}
