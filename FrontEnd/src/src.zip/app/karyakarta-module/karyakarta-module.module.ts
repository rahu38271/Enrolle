import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular'
import { KaryakartaComponent} from './karyakarta/karyakarta.component'
import { RouterModule } from '@angular/router'
import { FormsModule } from '@angular/forms'
import { AddKaryakartaComponent } from './add-karyakarta/add-karyakarta.component'
import { EditKaryakartaComponent } from './edit-karyakarta/edit-karyakarta.component'
import { DataTablesModule } from 'angular-datatables';

@NgModule({
  declarations: [KaryakartaComponent,AddKaryakartaComponent,EditKaryakartaComponent],
  imports: [
    CommonModule,
    IonicModule,
    FormsModule,
    DataTablesModule,
    RouterModule.forChild([{path:'', component:KaryakartaComponent}, {path:'add-karyakarta', component:AddKaryakartaComponent},{path:'edit-karyakarta', component:EditKaryakartaComponent}])
  ]
})
export class KaryakartaModuleModule { }
