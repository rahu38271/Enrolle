import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-karyakarta',
  templateUrl: './add-karyakarta.component.html',
  styleUrls: ['./add-karyakarta.component.scss'],
})
export class AddKaryakartaComponent implements OnInit {

  seniorityHeader:any = {
    header: 'ज्येष्ठता'
  };
  areaHeader:any = {
    header: ' एरिया नाव'
  }
  occupationHeader:any = {
    header: 'व्यवसाय'
  };
  bloodgroupHeader: any = {
    header: ' रक्तगट '
  }

  myForm;
  name = '';
  date = '';
  age = '';
  seniority = '';
  area = '';
  occupation = '';
  bloodgroup = '';
  mobile = '';
  whatsapp = '';
  radio1 = '';
  radio2 = '';
  info = '';
  
  constructor() { }

  ngOnInit() {}

  resetForm(){
    this.myForm.reset();
  }

}
