import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-karyakarta',
  templateUrl: './edit-karyakarta.component.html',
  styleUrls: ['./edit-karyakarta.component.scss'],
})
export class EditKaryakartaComponent implements OnInit {

  seniorityHeader:any = {
    header: 'ज्येष्ठता'
  };
  areaHeader:any = {
    header: ' एरिया नाव'
  }
  occupationHeader:any = {
    header: 'व्यवसाय'
  };
  bloodgroupHeader: any = {
    header: ' रक्तगट '
  }

  myForm;
  name = '';
  date = '';
  age = '';
  seniority = '';
  area = '';
  occupation = '';
  bloodgroup = '';
  mobile = '';
  whatsapp = '';
  radio1 = '';
  radio2 = '';
  info = '';
  
  constructor() { }

  ngOnInit() {}

  resetForm(){
    this.myForm.reset();
  }

}
