import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-officer',
  templateUrl: './add-officer.component.html',
  styleUrls: ['./add-officer.component.scss'],
})
export class AddOfficerComponent implements OnInit {

  designationHeader:any = {
    header: 'पदनाम'
  };
  departmentHeader:any = {
    header: 'विभाग'
  };

  myForm;
 
  mobile = '';
  office = '';
  name = '';
  home = '';
  email = '';
  floor = '';
  desk = '';
  assistant = '';
  Amobile = '';
  designation = '';
  department = '';
  work = '';

  constructor() { }

  ngOnInit() {}

  resetForm(){
    this.myForm.reset();
  }

}
