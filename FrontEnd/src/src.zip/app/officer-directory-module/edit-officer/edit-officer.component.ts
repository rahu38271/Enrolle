import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-officer',
  templateUrl: './edit-officer.component.html',
  styleUrls: ['./edit-officer.component.scss'],
})
export class EditOfficerComponent implements OnInit {

  myForm;
 
  mobile = '';
  office = '';
  name = '';
  home = '';
  email = '';
  floor = '';
  desk = '';
  assistant = '';
  Amobile = '';
  designation = '';
  department = '';
  work = '';

  constructor() { }

  ngOnInit() {}

  resetForm(){
    this.myForm.reset();
  }

}
