import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular'
import { FormsModule } from '@angular/forms'
import { RouterModule } from '@angular/router'
import { OfficeDirectoryComponent } from './office-directory/office-directory.component'
import { AddOfficerComponent } from './add-officer/add-officer.component'
import { EditOfficerComponent } from './edit-officer/edit-officer.component'
import { DataTablesModule } from 'angular-datatables';

@NgModule({
  declarations: [OfficeDirectoryComponent,AddOfficerComponent,EditOfficerComponent],
  imports: [
    CommonModule,
    IonicModule,
    FormsModule,
    DataTablesModule,
    RouterModule.forChild([{path:'', component:OfficeDirectoryComponent}, {path:'add-officer', component:AddOfficerComponent}, {path:'edit-officer', component:EditOfficerComponent}])
  ]
})
export class OfficerDirectoryModuleModule { }
