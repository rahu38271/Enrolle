import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { AlertController } from '@ionic/angular';
import * as xlsx from 'xlsx';
import html2pdf from 'html2pdf.js'

@Component({
  selector: 'app-govt-rules',
  templateUrl: './govt-rules.component.html',
  styleUrls: ['./govt-rules.component.scss'],
})
export class GovtRulesComponent implements OnInit {

  myForm1: any;
  Type = '';
  Department = '';
  CodeNumber = '';

  department: any = {
    header: 'संबंधित विभाग'
  };

  type: any = {
    header: ' प्रकार'
  };

  @ViewChild('epltable', { static: false }) epltable: ElementRef;

  constructor(public alertController: AlertController) { }

  resetForm(){
    this.myForm1.reset();
  }

  ngOnInit() {
    $('#table14').DataTable({
      lengthMenu: [ [25, 50, 100, -1], [25, 50, 100, "All"] ],
      pageLength: 25,
      autoWidth: false,
      "columnDefs": [
        { "width": "30px", "targets": 0 },
        { "width": "100px", "targets": 1 },
        { "width": "200px", "targets": 2 },
        { "width": "200px", "targets": 3 },
        { "width": "100px", "targets": 4 },
        { "width": "40px", "targets": 5 },
      ],
    });
   }

  async deleteRules() {
    const alert = await this.alertController.create({
      header: 'Delete शासन निर्णय ?',
      message: 'Are you sure want to delete this शासन निर्णय',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Yes',
          cssClass: 'deleteBtn',
          handler: () => {
            console.log('Confirm Ok');
          }
        }
      ],
    });

    await alert.present();
  }


  exportexcel() {
    const ws: xlsx.WorkSheet =
      xlsx.utils.table_to_sheet(this.epltable.nativeElement);
    const wb: xlsx.WorkBook = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(wb, ws, 'Sheet1');
    xlsx.writeFile(wb, 'epltable.xlsx');
  }

  pdf() {
    var element = document.getElementById('table');
    
    var opt = {
      margin: 0.2,
      filename: 'myfile.pdf',
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
    };

    // New Promise-based usage:
    html2pdf().set(opt).from(element).save();{};

    // Old monolithic-style usage:
    html2pdf(element, opt);
  }

}
