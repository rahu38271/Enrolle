import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-voterdata-management',
  templateUrl: './voterdata-management.component.html',
  styleUrls: ['./voterdata-management.component.scss'],
})
export class VoterdataManagementComponent implements OnInit {

  

  constructor() {
    
   }

  ngOnInit() {
    
  }

 

}

