import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomePage } from './home.page';

const routes: Routes = [
  {
    path: '',
    component: HomePage,
    children: [
      {
        path: 'birthday',
        loadChildren: () => import('../todays-birthday/todays-birthday.module').then(m => m.TodaysBirthdayPageModule)
      },
      {
        path: 'daily-work',
        loadChildren: () => import('../daily-work/daily-work.module').then(m => m.DailyWorkPageModule)
      },
      {
        path: 'daily-news',
        loadChildren: () => import('../daily-news/daily-news.module').then(m => m.DailyNewsPageModule)
      },
      {
        path: 'daily-routine',
        loadChildren: () => import('../daily-routine/daily-routine.module').then(m => m.DailyRoutinePageModule)
      },
    ]
  },
  {
    path: '',
    redirectTo: '/tabs/home/todays-birthday',
    pathMatch: 'full'
  }
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomePageRoutingModule {}
