import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-other-directory',
  templateUrl: './edit-other-directory.component.html',
  styleUrls: ['./edit-other-directory.component.scss'],
})
export class EditOtherDirectoryComponent implements OnInit {

  myForm;
 
  mobile = '';
  office = '';
  name = '';
  home = '';
  email = '';
  floor = '';
  desk = '';
  assistant = '';
  Wmobile = '';
  designation = '';
  village = '';
  work = '';
  date = '';

  constructor() { }

  ngOnInit() {}

  resetForm(){
    this.myForm.reset();
  }

}
