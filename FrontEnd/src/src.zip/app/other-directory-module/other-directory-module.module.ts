import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular'
import { RouterModule } from '@angular/router'
import { FormsModule} from '@angular/forms'
import { OtherDirectoryComponent } from './other-directory/other-directory.component'
import { AddOtherDirectoryComponent } from './add-other-directory/add-other-directory.component'
import { EditOtherDirectoryComponent } from './edit-other-directory/edit-other-directory.component'
import { DataTablesModule } from 'angular-datatables';

@NgModule({
  declarations: [OtherDirectoryComponent,AddOtherDirectoryComponent,EditOtherDirectoryComponent],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    DataTablesModule,
    RouterModule.forChild([{path:'', component:OtherDirectoryComponent},{path:'add-other-directory', component:AddOtherDirectoryComponent},{path:'edit-other-directory', component:EditOtherDirectoryComponent}])
  ]
})
export class OtherDirectoryModuleModule { }
