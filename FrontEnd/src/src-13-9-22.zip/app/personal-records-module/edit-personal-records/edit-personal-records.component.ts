import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-personal-records',
  templateUrl: './edit-personal-records.component.html',
  styleUrls: ['./edit-personal-records.component.scss'],
})
export class EditPersonalRecordsComponent implements OnInit {

  priorityHeader:any = {
    header: 'प्राधान्य'
  }
  statusHeader: any = {
    header: 'सद्यस्थिती'
  }
  remFrequencyHeader:any = {
    header: ' रिमाइंडर वारंवारता'
  }

 

  myForm;
  message = ''
  subject = '';
  
  date1 = '';
 
  priority = '';
  status = '';
 

  constructor() { }

  ngOnInit() {}

  resetForm(){
    this.myForm.reset();
  }

}
