import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { PopoverController, ToastController } from '@ionic/angular';
import { ContactService } from 'src/app/services/contact.service';
import { IonicToastService } from 'src/app/services/ionic-toast.service'

@Component({
  selector: 'app-add-contact',
  templateUrl: './add-contact.component.html',
  styleUrls: ['./add-contact.component.scss'],
})
export class AddContactComponent implements OnInit {
  districtList: any;
  talukaList: any;

  onKeyPress(event) {
    if ((event.keyCode >= 65 && event.keyCode <= 90) || (event.keyCode >= 97 && event.keyCode <= 122) || event.keyCode == 32 || event.keyCode == 46) {
      return true
    }
    else {
      return false
    }
  }

  keyPressNumbers(event) {
    var charCode = (event.which) ? event.which : event.keyCode;
    // Only Numbers 0-9
    if ((charCode < 48 || charCode > 57)) {
      event.preventDefault();
      return false;
    } else {
      return true;
    }
  }

  myForm;

  year: number = new Date().getFullYear();

  contactModal: any = {};

  constructor(public popoverController: PopoverController, public toastController: ToastController, public contact: ContactService, private toast: IonicToastService) {
    
  }

  getDistrict() {
    this.contact.getDistrictData().subscribe((data) => {
      if (data.length > 0) {
        //console.log(data);
        this.districtList = data;
      }
    }, (error) => {

    })
  }

  getTaluka(dId: any) {
    this.contact.getTalukaData(dId).subscribe((data) => {
      if (data.length > 0) {
        //console.log(data);
        this.contactModal.District = this.districtList.find(x=>x.dId = dId).districtName;
        this.talukaList = data;
      }
    }, (error) => {

    })
  }


  ngOnInit() {
    this.getDistrict();
  }

  resetForm() {
    this.myForm.reset();
  }


  onSubmit(f: NgForm) {
    if (this.contactModal.invalid) {
      return;
    }
    f.resetForm();
    // window.location.reload();
  }

  addContact() {
    // this.contactModal.BirthDate = this.ds.parseDate(this.contactModal.BirthDate.split('T')[0]+' '+this.contactModal.BirthDate.split('T')[1])
    // this.contactModal.BirthDate =new Date().toISOString();
    debugger;
    this.contactModal.BirthDate = this.contactModal.BirthDate + "T00:00:00";
    this.contactModal.Anniversary = this.contactModal.Anniversary + "T00:00:00";
    console.log(this.contactModal.District);
    console.log(this.contactModal.Taluka);
    console.log("data", this.contactModal);
    this.contact.addSingleContact(this.contactModal).subscribe((data) => {
      if (data) {
        this.toast.presentToast("Conact added successfully!", "success", 'checkmark-circle-sharp');
        console.log(data);
        this.contactModal = {};
      }
      else {
        this.toast.presentToast("Contact not saved", "danger", 'alert-circle-sharp');
      }
    }, (err) => {
      this.toast.presentToast("something went wrong!", "danger", 'alert-circle-sharp');
    });
  }
}

