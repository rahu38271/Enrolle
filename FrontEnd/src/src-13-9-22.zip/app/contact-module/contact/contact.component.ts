import { Component, OnInit,ViewChild,ElementRef } from '@angular/core';
import * as xlsx from 'xlsx';
import html2pdf from 'html2pdf.js'
import { ToastController, LoadingController } from '@ionic/angular';
import { ContactService } from 'src/app/services/contact.service'
import { Router } from '@angular/router';
import { LoaderService } from 'src/app/services/loader.service'
import { IonicToastService } from 'src/app/services/ionic-toast.service';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss'],
})
export class ContactComponent implements OnInit {

  Template = '';
  Content = '';
  NormalMsg = '';
  whatsappMsg = '';
  isShow = false;
  getContacts:any;
  searchMob: string;
  searchWeb: string;
  cp: number = 1;
  Cid:any;
  
  TemplateHeader:any = {
    header: 'Select Template'
  }

  currentDate = new Date();

  @ViewChild('epltable', { static: false }) epltable: ElementRef;

  constructor(public toastController: ToastController,public loadingController: LoadingController, private contact:ContactService, private router:Router, private loader:LoaderService, private toast:IonicToastService) { 
    this.loader.showLoading();
    this.contact.getContacts().subscribe(data=>{
      this.loader.hideLoader();
      if(data != 0){
        this.getContacts = data;
      }
      else{
        this.toast.presentToast("No data available", "danger", 'alert-circle-outline')
      }
    })
  }

  search(){
    this.isShow = !this.isShow
  }

  ngOnInit() {
    // $('#contactTable').DataTable({
    //   lengthMenu: [ [25, 50, 100, -1], [25, 50, 100, "All"] ],
    //   pageLength: 25,
    //   autoWidth: false,
    //   "columnDefs": [
    //     { "width": "20px", "targets": 0 },
    //     { "width": "40px", "targets": 1 },
    //     { "width": "100px", "targets": 2 },
    //     { "width": "70px", "targets": 3 },
    //     { "width": "70px", "targets": 4 },
    //     { "width": "70px", "targets": 5 },
    //     { "width": "70px", "targets": 6 },
    //     { "width": "200px", "targets": 7 },
    //     { "width": "40px", "targets": 8 },
    //     { "width": "40px", "targets": 9 }
        
    //   ],
    // });
  }

  exportexcel() {
  
    const ws: xlsx.WorkSheet =
    xlsx.utils.table_to_sheet(this.epltable.nativeElement);
    const wb: xlsx.WorkBook = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(wb, ws, 'Sheet1');
    xlsx.writeFile(wb, 'contact.xlsx');
  }

  async downloadExcel() {
    const toast = await this.toastController.create({
      message: 'Request added to export.',
      duration: 2000,
      position: 'top',
      color: 'success',
    });
    toast.present();
  }

  async downloadPDF() {
    const toast = await this.toastController.create({
      message: 'Request added to download doc.',
      duration: 2000,
      position: 'top',
      color: 'primary',
    });
    toast.present();
  }

  pdf() {
    var element = document.getElementById('contactTable');
    
    var opt = {
      margin: 0.2,
      filename: 'myfile.pdf',
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
    };

    // New Promise-based usage:
    html2pdf().set(opt).from(element).save();{};

    // Old monolithic-style usage:
    html2pdf(element, opt);
  }

  conDetails(id:any){
    this.router.navigate(["contact/contact-details",id])
  }


}
