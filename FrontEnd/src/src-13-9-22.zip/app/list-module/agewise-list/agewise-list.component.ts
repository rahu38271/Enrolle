import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agewise-list',
  templateUrl: './agewise-list.component.html',
  styleUrls: ['./agewise-list.component.scss'],
})
export class AgewiseListComponent implements OnInit {

  keyPressNumbers(event) {
    var charCode = (event.which) ? event.which : event.keyCode;
    // Only Numbers 0-9
    if ((charCode < 48 || charCode > 57)) {
      event.preventDefault();
      return false;
    } else {
      return true;
    }
  }

  isShow = false;
   
  search(){
    this.isShow = !this.isShow
  }

  constructor() { }

  ngOnInit() {}

}
