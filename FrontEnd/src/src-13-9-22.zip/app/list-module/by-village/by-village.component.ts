import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-by-village',
  templateUrl: './by-village.component.html',
  styleUrls: ['./by-village.component.scss'],
})
export class ByVillageComponent implements OnInit {

  isShow = false;

  constructor() { }

  search(){
    this.isShow = !this.isShow
  }

  ngOnInit() {
    $('#villageTable').DataTable({
      lengthMenu: [ [25, 50, 100, -1], [25, 50, 100, "All"] ],
      pageLength: 25,
      autoWidth: false,
      "columnDefs": [
        { "width": "20px", "targets": 0 },
        { "width": "100px", "targets": 1 },
        { "width": "70px", "targets": 2 }
      ],
    });
  }

}
