import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alphabetwise-list',
  templateUrl: './alphabetwise-list.component.html',
  styleUrls: ['./alphabetwise-list.component.scss'],
})
export class AlphabetwiseListComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
