import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-appointment',
  templateUrl: './edit-appointment.component.html',
  styleUrls: ['./edit-appointment.component.scss'],
})
export class EditAppointmentComponent implements OnInit {

  statusHeader:any = {
    header: 'सद्यस्थिती '
  }
  preferenceHeader: any = {
    header: 'प्राधान्य'
  }

  modeType:any = {
    header: 'माध्यमाचे नाव'
  }

  myForm;
  status = '';
  subject = '';
  Edate = '';
  responsibility = '';
  priority = '';
  inpresence = '';
  place = '';
  date = '';

  constructor() { }

  ngOnInit() {}

  resetForm(){
    this.myForm.reset();
  }

}
